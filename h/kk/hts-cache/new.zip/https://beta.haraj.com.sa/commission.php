<!doctype html><html dir="rtl" lang="ar"><head><link rel="dns-prefetch" href="https://betacdn.haraj.com.sa"><link rel="dns-prefetch" href="https://graphql.haraj.com.sa"><link rel="dns-prefetch" href="https://imgcdn.haraj.com.sa"><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><title>موقع حراج</title><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><meta name="theme-color" content="#0473c0"><meta name="format-detection" content="telephone=yes"><meta property="twitter:account_id" content="4503599629495409"><meta name="twitter:card" id="twitter-card" content="summary"><meta name="twitter:site" content="@haraj"><meta id="meta-twitter-image" name="twitter:image:media" content="https://betacdn.haraj.com.sa/assets/images/1024_icon.png"><meta name="twitter:site:id" content="131885812"><meta name="twitter:app:name:iphone" content="حراج"><meta name="twitter:app:id:iphone" content="662557215"><meta name="twitter:app:name:ipad" content="حراج"><meta name="twitter:app:id:ipad" content="662557215"><meta name="twitter:app:name:googleplay" content="حراج"><meta name="twitter:app:id:googleplay" content="com.haraj.app"><meta property="og:country-name" content="Saudi Arabia"><meta property="og:site_name" content="حراج"><link rel="icon" sizes="128x128" href="https://betacdn.haraj.com.sa/assets/images/128_icon.png"><link rel="icon" sizes="152x152" href="https://betacdn.haraj.com.sa/assets/images/152_icon.png"><link rel="icon" sizes="192x192" href="https://betacdn.haraj.com.sa/assets/images/192_icon.png"><link rel="icon" sizes="256x256" href="https://betacdn.haraj.com.sa/assets/images/256_icon.png"><link rel="icon" sizes="512x512" href="https://betacdn.haraj.com.sa/assets/images/512_icon.png"><link rel="icon" sizes="1024x1024" href="https://betacdn.haraj.com.sa/assets/images/1024_icon.png"><link rel="preconnect" href="https://graphql.haraj.com.sa"><link rel="preconnect" href="https://www.google-analytics.com"><link rel="manifest" href="/manifest.webmanifest"><script>(function (a, s, y, n, c, h, i, d, e) {
				s.className += ' ' + y;
				h.start = 1 * new Date();
				h.end = i = function () {
					s.className = s.className.replace(RegExp(' ?' + y), '');
				};
				(a[n] = a[n] || []).hide = h;
				setTimeout(function () {
					i();
					h.end = null;
				}, c);
				h.timeout = c;
			})(
				window,
				document.documentElement,
				'async-hide',
				'dataLayer',
				4000,
				{ 'GTM-WMS952R': true }
			);</script><link href="https://betacdn.haraj.com.sa/assets/css/main.d017aa95570a03e95f0d.css" rel="stylesheet"><link rel="preload" href="https://betacdn.haraj.com.sa/main.4b844541a1270c6a0146.js" as="script" crossorigin="anonymous"><meta name="apple-mobile-web-app-title" content="موقع حراج" /><meta name="apple-mobile-web-app-capable" content="yes" /><meta name="apple-mobile-web-app-status-bar-style" content="default" /><meta name="theme-color" content="#0473c0" /><link rel="apple-touch-startup-image" sizes="1024x1024" href="https://betacdn.haraj.com.sa/assets/images/icon_1024x1024.74fb1b1defff023ade4b9ef3b6b2ac7c.png" /><link rel="apple-touch-icon" sizes="512x512" href="https://betacdn.haraj.com.sa/assets/images/icon_512x512.7066411fca0d089f078ddf49d59df968.png" /><link rel="apple-touch-icon" sizes="384x384" href="https://betacdn.haraj.com.sa/assets/images/icon_384x384.12d8b38b0a81ff939e9768f4105093eb.png" /><link rel="apple-touch-icon" sizes="256x256" href="https://betacdn.haraj.com.sa/assets/images/icon_256x256.e1fab9740fc56bf67a9553750b7c9414.png" /><link rel="apple-touch-icon" sizes="192x192" href="https://betacdn.haraj.com.sa/assets/images/icon_192x192.3412c457e79a23d6a92f96ad8eeefc64.png" /><link rel="apple-touch-icon" sizes="128x128" href="https://betacdn.haraj.com.sa/assets/images/icon_128x128.cc86407e91021ad6957be73c5f43b9b1.png" /><link rel="apple-touch-icon" sizes="96x96" href="https://betacdn.haraj.com.sa/assets/images/icon_96x96.5e07e9b4868f8e0113751d416f54a860.png" /><link rel="manifest" href="https://betacdn.haraj.com.sa/manifest.webmanifest" crossorigin="anonymous" /></head><body><noscript><div class="header"><div class="headContent"><div class="headLogo"><a class="logo" href="/"><img alt="حراج" src="https://haraj.azureedge.net/static/images5/haraj-logo.png"></a></div></div></div><div id="nojs"><h2>يجب تفعيل الجافاسكربت لاستخدام الموقع بشكل صحيح</h2><h4>يمكنك استخدام الموقع القديم من <a href="https://legacy.haraj.com.sa/">هنا</a></h4></div></noscript><div id="root"></div><script type="module">import { Workbox } from 'https://storage.googleapis.com/workbox-cdn/releases/4.0.0/workbox-window.prod.mjs';
			try {
				if ('serviceWorker' in navigator) {
					const wb = new Workbox('/sw.js');

					// wb.addEventListener('installed', async event => {
					// 	if (event.isUpdate) {
					// 		const message =
					// 			'يوجد نسخة جديدة من الموقع هل تود استخدامها ؟';
					// 		if (confirm(message)) {
					// 			window.location.reload();
					// 		}
					// 	}
					// });
					wb.register();
				}
			} catch (error) {
				console.log(error);
			}</script><script src="https://betacdn.haraj.com.sa/main.4b844541a1270c6a0146.js" crossorigin="anonymous"></script></body></html>